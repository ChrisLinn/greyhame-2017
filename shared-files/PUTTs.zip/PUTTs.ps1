﻿<#	

#>

#[void][system.Reflection.Assembly]::LoadWithPartialName("PresentationFramework")
function GetObfucscatedCommand {
	$VarName = -join (Get-Random -Input ((((65 .. 90) + (97 .. 122) | % { [char]$_ })) + (0 .. 9)) -Count 5)
	
	# Randomly select obfuscated syntax for invoking the contents of the randomly-named environment variable.
	# More complete obfuscation options can be imported from Invoke-Obfuscation.
	$DGGetChildItemSyntaxRandom = Get-Random -Input @('Get-C`hildItem', 'Child`Item', 'G`CI', 'DI`R', 'L`S')
	$DGGetCommandSyntaxRandom = Get-Random -Input @('Get-C`ommand', 'Co`mmand', 'G`CM')
	$DGInvokeSyntaxRandom = Get-Random -Input @('IE`X', 'Inv`oke-Ex`pression', ".($DGGetCommandSyntaxRandom ('{1}e{0}'-f'x','i'))")
	
	$DGEnvVarSyntax = @()
	$DGEnvVarSyntax += "(" + $DGGetChildItemSyntaxRandom + " env:$VarName).Value"
	$DGEnvVarSyntax += "`$env:$VarName"
	$DGEnvVarSyntaxRandom = (Get-Random -Input $DGEnvVarSyntax)
	
	$DGInvokeEnvVarSyntax = @()
	$DGInvokeEnvVarSyntax += $DGInvokeSyntaxRandom + ' ' + $DGEnvVarSyntaxRandom
	$DGInvokeEnvVarSyntax += $DGEnvVarSyntaxRandom + '|' + $DGInvokeSyntaxRandom
	return (Get-Random -Input $DGInvokeEnvVarSyntax)
	
}
Add-Type -Assembly PresentationFramework
[xml]$XAML = @'
<Window 
		x:Class="WpfApp1.MainWindow"
		xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        xmlns:d="http://schemas.microsoft.com/expression/blend/2008"
        xmlns:mc="http://schemas.openxmlformats.org/markup-compatibility/2006"
		xmlns:local="clr-namespace:WpfApp1"
		mc:Ignorable="d"
        Title="Powershell Useful ToolSet V0.1 By Moriarty@DMZLab" Height="350" Width="566.77" WindowStyle="ToolWindow" Background="#FFF5F1F1" Topmost="True" WindowStartupLocation="CenterScreen">
    <Grid>
        <Grid.ColumnDefinitions>
            <ColumnDefinition Width="280*"/>
            <ColumnDefinition Width="279*"/>
        </Grid.ColumnDefinitions>
        <TabControl x:Name="tabctl_1" VerticalAlignment="Top" Height="322" Grid.ColumnSpan="2">
            <TabItem x:Name="tabItem_obf" Header="Obfustcator">
                <Grid Background="#FFE5E5E5" Margin="0">
                    <Grid.ColumnDefinitions>
                        <ColumnDefinition Width="178*"/>
                        <ColumnDefinition Width="371*"/>
                    </Grid.ColumnDefinitions>
                    <Label Grid.ColumnSpan="2" Content="Randomly obfuscate powershell command (using enviroment variable):" HorizontalAlignment="Left" Height="23" Margin="10,10,0,0" VerticalAlignment="Top" Width="529" HorizontalContentAlignment="Center" Foreground="Red"/>
                    <Button x:Name="btn_go" Content="GO" Grid.Column="1" HorizontalAlignment="Left" Height="19" Margin="31,126,0,0" VerticalAlignment="Top" Width="115"/>
                    <TextBox x:Name="textbox_output" Grid.ColumnSpan="2" HorizontalAlignment="Left" Height="85" Margin="10,36,0,0" TextWrapping="Wrap" Text="" VerticalAlignment="Top" Width="529"/>
                </Grid>
            </TabItem>
            <TabItem x:Name="tabItem_gen" Header="Generator">
                <Grid Background="#FFE5E5E5"/>
            </TabItem>
        </TabControl>

    </Grid>
</Window>

'@
$xmlns = New-Object System.Xml.XmlNamespaceManager($XAML.NameTable)
$xmlns.AddNamespace('x', 'http://schemas.microsoft.com/winfx/2006/xaml')
$XAML.Window.RemoveAttribute('x:Class')
$XAML.Window.RemoveAttribute('mc:Ignorable')
$XAML.Window.RemoveAttribute('xmlns:local')
$reader = New-Object System.Xml.XmlNodeReader $XAML
try
{
	$Form = [Windows.Markup.XamlReader]::Load($reader)
}
catch
{
	Write-Host -ForegroundColor Red "Processing XAML Failed!"
	exit
}

$XAML.SelectNodes("//*[@x:Name]",$xmlns) | %{
	Set-Variable -Name $_.Name -Value $Form.FindName($_.Name)
}
$btn_go.Add_Click({
		#[system.Windows.Forms.MessageBox]::Show("Hi")
		$textbox_output.Text = GetObfucscatedCommand
})
$Form.ShowDialog() | Out-Null
