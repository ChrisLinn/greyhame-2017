import time
i = 0
while 1:
    i += 1
    print(i)
    time.sleep(2)
