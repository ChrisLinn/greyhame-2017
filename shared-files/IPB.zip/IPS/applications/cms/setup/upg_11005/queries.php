<?php

$SQL[]	= "ALTER TABLE ccs_database_fields ADD field_is_numeric TINYINT(1) NOT NULL DEFAULT '0';";


