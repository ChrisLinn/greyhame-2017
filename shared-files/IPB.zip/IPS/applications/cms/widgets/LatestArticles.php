<?php
/**
 * @brief		LatestArticles Widget
 * @author		<a href='http://www.invisionpower.com'>Invision Power Services, Inc.</a>
 * @copyright	(c) 2001 - SVN_YYYY Invision Power Services, Inc.
 * @license		http://www.invisionpower.com/legal/standards/
 * @package		IPS Social Suite
 * @subpackage	content
 * @since		21 Mar 2014
 * @version		SVN_VERSION_NUMBER
 */

namespace IPS\cms\widgets;

/* To prevent PHP errors (extending class does not exist) revealing path */
if ( !defined( '\IPS\SUITE_UNIQUE_KEY' ) )
{
	header( ( isset( $_SERVER['SERVER_PROTOCOL'] ) ? $_SERVER['SERVER_PROTOCOL'] : 'HTTP/1.0' ) . ' 403 Forbidden' );
	exit;
}

/**
 * LatestArticles Widget
 */
class _LatestArticles extends \IPS\Widget\PermissionCache
{
	/**
	 * @brief	Widget Key
	 */
	public $key = 'LatestArticles';
	
	/**
	 * @brief	App
	 */
	public $app = 'cms';
		
	/**
	 * @brief	Plugin
	 */
	public $plugin = '';

		/**
	 * Specify widget configuration
	 *
	 * @return	null|\IPS\Helpers\Form
	 */
	public function configuration( &$form=null )
 	{
 		if ( $form === null )
 		{
	 		$form = new \IPS\Helpers\Form;
 		}
 		
 		$databases = array();
 		foreach( \IPS\cms\Databases::databases() as $db )
 		{
	 		$databases[ $db->id ] = $db->_title;
 		}
 		
		$form->add( new \IPS\Helpers\Form\Select( 'database', ( isset( $this->configuration['database'] ) ? $this->configuration['database'] : NULL ), FALSE, array( 'options' => $databases ) ) );
		$form->add( new \IPS\Helpers\Form\Number( 'number_to_show', isset( $this->configuration['number_to_show'] ) ? $this->configuration['number_to_show'] : 5, TRUE ) );
		
		return $form;
 	}

	/**
	 * Render a widget
	 *
	 * @return	string
	 */
	public function render()
	{
		if ( isset( $this->configuration['database'] ) )
		{
			try
			{
				$database = \IPS\cms\Databases::load( intval( $this->configuration['database'] ) );
				$database->preLoadWords();
				\IPS\cms\Databases\Dispatcher::i()->setDatabase( $database->id );
			}
			catch ( \OutOfRangeException $e )
			{
				return \IPS\Member::loggedIn()->language()->get('block_no_database_selected');
			}
			
			$recordClass = 'IPS\cms\Records' . $database->id;
			$records = $recordClass::getItemsWithPermission( array(), NULL, isset( $this->configuration['number_to_show'] ) ? $this->configuration['number_to_show'] : 5 );
			
			if ( count( $records ) )
			{
				try
				{
					return $this->output( $database, $records );
				}
				catch( \OutOfRangeException $ex )
				{
					return $ex->getMessage();
				}
			}
			else
			{
				return '';
			}
		}
		
		return \IPS\Member::loggedIn()->language()->get('block_no_database_selected');
	}
}